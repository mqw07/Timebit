import { defaultSettings, isMode, phaseMinutes, toDurationMs, validateModeSettings } from "./modes.js";
import { activeStudyInterval } from "./study-time.js";

export const STATE_KEY = "timebit";

function readyPhase(timer, settings, phase = timer.phase) {
  const next = {
    ...timer, phase, status: "ready", runId: null,
    endsAt: null, pausedRemainingMs: null, completedPhase: null, expiredAt: null, studyStartedAt: null,
  };
  return { ...next, durationMs: toDurationMs(phaseMinutes(next, settings)) };
}

export function createInitialState() {
  const settings = defaultSettings();
  return {
    schemaVersion: 1,
    revision: 0,
    tasksRevision: 0,
    tasks: [],
    studyIntervals: [],
    settings,
    delivery: null,
    timer: readyPhase({
      mode: settings.selectedMode,
      phaseId: 0,
      cascadeIndex: 0,
      pomodoroCycle: 0,
      completedStudyBlocks: 0,
    }, settings, "study"),
  };
}

export function remainingMs(timer, now) {
  if (timer.status === "running") {
    return Math.max(0, Math.min(timer.durationMs, timer.endsAt - now));
  }
  return timer.status === "paused" ? timer.pausedRemainingMs : timer.durationMs;
}

export function formatCountdown(milliseconds) {
  const seconds = Math.ceil(milliseconds / 1000);
  return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
}

export function overtimeMs(timer, now) {
  return timer.expiredAt == null ? null : Math.max(0, now - timer.expiredAt);
}

export function formatOvertime(milliseconds) {
  return `-${formatCountdown(Math.floor(milliseconds / 1_000) * 1_000)}`;
}

function advance(timer, settings, completed) {
  const finishedStudy = timer.phase === "study" && completed;
  const next = {
    ...timer,
    completedStudyBlocks: timer.completedStudyBlocks + Number(finishedStudy),
  };
  if (timer.mode === "pomodoro") {
    if (timer.phase === "study") {
      next.pomodoroCycle += Number(finishedStudy);
      const phase = next.pomodoroCycle >= settings.pomodoro.longBreakEvery ? "longBreak" : "shortBreak";
      return readyPhase(next, settings, phase);
    }
    if (timer.phase === "longBreak") next.pomodoroCycle = 0;
  } else {
    if (timer.phase === "study") {
      const finalBlock = timer.cascadeIndex === settings.cascade.study.length - 1;
      return readyPhase(next, settings, finalBlock ? "longBreak" : "shortBreak");
    }
    next.cascadeIndex = timer.phase === "longBreak" ? 0 : timer.cascadeIndex + 1;
  }
  return readyPhase(next, settings, "study");
}

export function nextPhase(timer, settings) {
  return advance(timer, settings, true);
}

function update(state, changes) {
  return { ...state, ...changes, revision: state.revision + 1 };
}

function stopRun(state, timer, now, changes = {}) {
  const interval = activeStudyInterval(state.timer, now);
  const next = { ...changes, timer };
  if (interval) next.studyIntervals = [...(state.studyIntervals ?? []), interval];
  return update(state, next);
}

export function reconcile(state, now) {
  const { timer } = state;
  if (timer.status !== "running") return state;

  if (timer.endsAt <= now) {
    const next = {
      ...nextPhase(timer, state.settings), phaseId: state.revision + 1,
      completedPhase: timer.phase, expiredAt: timer.endsAt,
    };
    return stopRun(state, next, now, {
      // Claim this run's alert in the same write as the natural completion.
      delivery: {
        phaseId: timer.phaseId ?? 0,
        runId: timer.runId ?? state.revision,
      },
    });
  }

  if (timer.phase === "study" && timer.studyStartedAt == null) {
    // An active timer from an earlier build starts recording at the first read after the update.
    return update(state, { timer: { ...timer, studyStartedAt: now } });
  }
  return state;
}

export function applyCommand(state, command, now) {
  const { timer, settings } = state;
  switch (command.type) {
    case "timer.start":
      if (timer.status === "running") return { state };
      return { state: update(state, {
        timer: {
          ...timer, phaseId: timer.phaseId ?? 0, runId: state.revision + 1,
          status: "running", endsAt: now + remainingMs(timer, now), pausedRemainingMs: null,
          completedPhase: null, expiredAt: null, studyStartedAt: timer.phase === "study" ? now : null,
        },
      }) };
    case "timer.pause":
      if (timer.status !== "running") return { state };
      return { state: stopRun(state, {
        ...timer,
        status: "paused",
        endsAt: null,
        pausedRemainingMs: remainingMs(timer, now),
        studyStartedAt: null,
      }, now) };
    case "timer.reset":
      return { state: stopRun(state, {
        ...timer, phaseId: state.revision + 1, runId: null,
        status: "ready", endsAt: null, pausedRemainingMs: null, completedPhase: null,
        expiredAt: null, studyStartedAt: null,
      }, now) };
    case "timer.skip":
      return { state: stopRun(state, { ...advance(timer, settings, false), phaseId: state.revision + 1 }, now) };
    case "mode.select": {
      if (!isMode(command.mode)) return { state, error: "Choose a valid timing mode." };
      if (timer.mode === command.mode) return { state };
      const nextSettings = { ...settings, selectedMode: command.mode };
      const next = readyPhase({
        ...timer, mode: command.mode, phaseId: state.revision + 1, cascadeIndex: 0, pomodoroCycle: 0,
      }, nextSettings, "study");
      return { state: stopRun(state, next, now, { settings: nextSettings }) };
    }
    case "mode.save": {
      const { mode, values } = command;
      const errors = validateModeSettings(mode, values);
      if (Object.keys(errors).length) return { state, errors };
      const { study, shortBreak, longBreak } = values;
      const modeSettings = { study, shortBreak, longBreak };
      if (mode === "pomodoro") modeSettings.longBreakEvery = values.longBreakEvery;
      else modeSettings.study = [...study];
      const nextSettings = { ...settings, [mode]: modeSettings };
      return { state: update(state, {
        settings: nextSettings,
        timer: timer.mode === mode && timer.status === "ready"
          ? { ...timer, durationMs: toDurationMs(phaseMinutes(timer, nextSettings)) }
          : timer,
      }) };
    }
    case "notifications.set":
      if (typeof command.enabled !== "boolean") return { state, error: "Choose a valid notification preference." };
      if ((settings.completionNotifications !== false) === command.enabled) return { state };
      return { state: update(state, { settings: { ...settings, completionNotifications: command.enabled } }) };
    case "check-in.set":
      if (typeof command.enabled !== "boolean") return { state, error: "Choose a valid check-in preference." };
      if ((settings.openStudyCheckIn !== false) === command.enabled) return { state };
      return { state: update(state, { settings: { ...settings, openStudyCheckIn: command.enabled } }) };
    case "sound.mute":
      if (typeof command.muted !== "boolean") return { state, error: "Choose a valid mute preference." };
      if ((settings.soundMuted === true) === command.muted) return { state };
      return { state: update(state, { settings: { ...settings, soundMuted: command.muted } }) };
    case "sound.volume":
      if (!Number.isInteger(command.volume) || command.volume < 0 || command.volume > 100) {
        return { state, error: "Set a volume from 0 to 100%." };
      }
      if (settings.soundVolume === command.volume) return { state };
      return { state: update(state, { settings: { ...settings, soundVolume: command.volume } }) };
    default:
      return { state, error: "Unknown Timebit command." };
  }
}
