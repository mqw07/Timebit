# Timebit

Timebit is a Chrome extension for Pomodoro and Cascade study sessions. It uses plain HTML, CSS, and JavaScript and needs no build step.

## Load the extension

1. Open `chrome://extensions` in Chrome 127 or later.
2. Turn on **Developer mode**, choose **Load unpacked**, and select the `extension` directory.
3. Open Timebit from the extensions menu. Choose a mode on the timer, or use the gear to open **Settings**. From there, open **Timing modes**, **Manage tasks**, or **Notifications & sound**.

Every phase waits for **Start**. **Reset** restores the current phase's original duration. Saving settings updates a ready phase and future phases. Running and paused phases retain their original duration. Changing modes queues the first study phase in the new mode.

Pin Timebit from Chrome’s Extensions menu to see minutes remaining. The badge shows `Ⅱ` while paused and `0` after a block finishes. Hover over the icon for the current phase and remaining time as of the last refresh.

Timebit saves the timer deadline and settings locally. The Chrome service worker finishes the current phase in the background, even with the popup closed. If Chrome is closed or the computer sleeps past the deadline, Timebit catches up when Chrome resumes and leaves the next phase waiting for Start. Chrome may delay background alarms, particularly for very short test durations.

When a study block ends, Timebit saves the waiting break, plays a soft chime, and tries to open the check-in if Chrome is in focus. If Chrome can't open it, Timebit uses the desktop notification setting. Clicking a notification opens the timer. The break starts when you press **Start**.

Closing the check-in keeps your tasks and the waiting break. Reopen Timebit to pick up the check-in. Otherwise, the toolbar popup remembers your page during the Chrome session. When a break ends, Timebit leaves the next study block ready to start and sends a notification if enabled.

After a study block or break ends, the timer shows overtime as a negative countdown. It continues from the original deadline across sleep and restarts. The next phase waits for **Start**. Starting, skipping, or resetting the queued phase clears overtime.

The timer footer shows **Today** study time from this update onward. It includes time spent studying before a pause, skip, or reset. Breaks, pauses, waiting time, and overtime are excluded. A study block that crosses midnight contributes only its time within the current local day.

Use **Notifications & sound** in the gear menu to control desktop notifications, automatic check-ins, and sound. Automatic check-ins and notifications are enabled by default. You can preview the chime, mute it, or set its volume from 0 to 100%. Chrome and your system settings control whether desktop notifications appear.

Add tasks below the timer controls. The same checklist is available after a study block finishes and on the **Manage tasks** page, which also has **Clear completed** and **Clear all**. Timebit saves changes immediately on this device, including when you change modes or restart Chrome.

To smoke-test recovery, use a short study block and close the popup or quit Chrome before it ends. After the deadline, reopen Chrome and check that the next break is waiting for Start. Pressing Pause before you quit should instead preserve the time that was left.

## Run the tests

With Node.js 22 or later, run the timer unit tests and mocked Chrome storage integration tests.

```sh
npm test
```

The browser suite uses an isolated profile in installed Google Chrome. It uses the Chrome DevTools Protocol to load the unpacked extension, so use a current Chrome build. Install Playwright for test use and run the browser suite.

```sh
npm install --no-save --package-lock=false playwright
npm run test:chrome
```

If Playwright is already provided by your runtime, set `TIMEBIT_PLAYWRIGHT` to the absolute path to its `playwright/test` entry point. The suite covers the timer and toolbar, checklist changes across views, overtime and daily study time, background chimes and notifications, and restart recovery. Set `TIMEBIT_EXTENSION` to the absolute path to an extracted build's `extension` folder to test the contents of a ZIP.
